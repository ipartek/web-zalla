package persistencia;

public class GestionPersistencia {

}
