package config;

public class Configuracion {
	public static final String NOMBRE_FICHERO = "C:\\PracticasJava\\MIS_FICHEROS\\personas.txt";

}
