package empresa;

public interface Arreglador {
	void arreglar();
}
