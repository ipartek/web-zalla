package colecciones;

public class ContenedorGenericos<T> {
	T variable1;

	public ContenedorGenericos(T variable1) {
		super();
		this.variable1 = variable1;
	}

}
