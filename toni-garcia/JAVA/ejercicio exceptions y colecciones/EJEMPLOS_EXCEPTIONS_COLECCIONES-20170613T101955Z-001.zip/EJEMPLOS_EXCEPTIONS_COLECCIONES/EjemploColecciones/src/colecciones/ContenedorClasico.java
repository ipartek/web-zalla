package colecciones;

public class ContenedorClasico {
	Object variable1;

	public ContenedorClasico(Object variable1) {
		super();
		this.variable1 = variable1;
	}

}
