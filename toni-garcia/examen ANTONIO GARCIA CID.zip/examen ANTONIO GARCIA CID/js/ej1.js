
function Eliminar(i) {
    document.getElementById('tblProductos').deleteRow(i);
}
