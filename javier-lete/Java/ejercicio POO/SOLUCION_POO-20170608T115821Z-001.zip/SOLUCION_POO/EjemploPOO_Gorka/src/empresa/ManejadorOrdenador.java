package empresa;

public interface ManejadorOrdenador {
	void teclear();
}
