package conduccion;

public interface Conductor
{
    public void conducir();
}