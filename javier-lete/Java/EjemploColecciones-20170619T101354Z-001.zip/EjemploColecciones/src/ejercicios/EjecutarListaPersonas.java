package ejercicios;

import java.util.ArrayList;
import java.util.List;

import colecciones.OtraClase;
import conduccion.Conductor;
import conduccion.Dni;
import conduccion.Estudiante;
import conduccion.Persona;
import conduccion.PersonaConductora;
import geometria.Punto;

public class EjecutarListaPersonas {

	public static void main(String[] args) {
		List listaPersonas = crearListaPersonas();
		recorrerListaPersonas(listaPersonas);

	}

	// Cargar un ArrayList con 4 personas y lo devuelve
	public static List crearListaPersonas() {
		List listaPersonas = new ArrayList();
		Dni dni1 = new Dni("27383444", 'R');
		Persona persona1 = new Persona("Roberto", "Martin", dni1);
		listaPersonas.add(persona1);
		Dni dni2 = new Dni("83224112", 'A');
		Persona persona2 = new Persona("Maria", "Perez", dni2);
		listaPersonas.add(persona2);
		Dni dni3 = new Dni("12345678", 'X');
		Persona persona3 = new Persona("Jose", "Salgado", dni3);
		listaPersonas.add(persona3);
		Dni dni4 = new Dni("87654321", 'Y');
		Persona persona4 = new Persona("Javi", "Lopez", dni4);
		listaPersonas.add(persona4);
		listaPersonas.add(new Punto(3, 6));	
		return listaPersonas;
	}

	// Recorre un List con personas
	public static void recorrerListaPersonas(List listaPersonas) {
		Persona persona = null;
		for (int i = 0; i < listaPersonas.size(); i++) {
			persona = (Persona) listaPersonas.get(i);
			System.out.println(listaPersonas.get(i));
		}
	}

}
