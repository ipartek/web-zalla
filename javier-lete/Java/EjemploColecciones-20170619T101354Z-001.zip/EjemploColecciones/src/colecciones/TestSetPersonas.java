package colecciones;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import conduccion.Dni;
import conduccion.Persona;
import geometria.Punto;

public class TestSetPersonas {

	public static void main(String[] args) {
		Persona persona1 = new Persona("Paquito", "Perez", new Dni("254685698", 'x'));
		Persona persona2 = new Persona("Paquito", "Gomez", new Dni("548632158", 'z'));
		Persona persona3 = new Persona("Carlos", "Gomez", new Dni("458796543", 'x'));
		Persona persona4 = new Persona("Jenny", "Garcia", new Dni("587623145", 's'));
		Persona persona5 = new Persona("Jenny", "Garcia", new Dni("587623145", 's'));
		Persona persona6 = new Persona("Olatz", "Mart�n", new Dni("254685698", 'x'));

		Set<Persona> setPersonas = new HashSet<Persona>();
		boolean insertado = false;
		insertado = setPersonas.add(persona1);
		System.out.println("insertado: " + insertado);
		insertado = setPersonas.add(persona2);
		System.out.println("insertado: " + insertado);
		insertado = setPersonas.add(persona3);
		System.out.println("insertado: " + insertado);
		insertado = setPersonas.add(persona4);
		System.out.println("insertado: " + insertado);
		insertado = setPersonas.add(persona5);
		System.out.println("insertado: " + insertado);
		insertado = setPersonas.add(persona6);
		System.out.println("insertado: " + insertado);
		recorrer(setPersonas);

	}

	public static void recorrer(Set<Persona> setPersonas) {
		//
		Iterator<Persona> iterator = setPersonas.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		for (Persona persona : setPersonas) {
			// System.out.println(persona);
		}
	}

}
