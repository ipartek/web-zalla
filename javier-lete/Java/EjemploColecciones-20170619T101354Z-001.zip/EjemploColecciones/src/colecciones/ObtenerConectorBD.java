package colecciones;

public class ObtenerConectorBD {
	public static final String BD_PROYECTO_ORACLE = "Oracle";
	public static final String BD_PROYECTO_MYSQL = "MySql";
	public static String BD_PROYECTO_CONFIG = "MySql";

	public static ConectorBD obtenerConexionBD() {
		if (BD_PROYECTO_CONFIG.equals(BD_PROYECTO_ORACLE)) {
			return new ConectorOracle();
		} else {
			return new ConectorMySql();
		}
	}

}
