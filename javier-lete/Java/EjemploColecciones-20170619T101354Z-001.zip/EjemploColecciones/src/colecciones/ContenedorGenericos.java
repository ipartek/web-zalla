package colecciones;

public class ContenedorGenericos<E> {
	E variable1;

	public ContenedorGenericos() {
		super();
	}

	public ContenedorGenericos(E variable1) {
		super();
		this.variable1 = variable1;
	}

	public E getVariable1() {
		return variable1;
	}

	public void setVariable1(E variable1) {
		this.variable1 = variable1;
	}

}
