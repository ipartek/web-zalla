package colecciones;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import conduccion.Dni;
import conduccion.Persona;

public class TestMap {

	public static void recorrer(Map<String, Persona> mapPersonasDniString) {
		Set<String> setClaves = mapPersonasDniString.keySet();
		Iterator<String> iteradorClaves = setClaves.iterator();
		String clave =null;
		Persona persona = null;
		System.out.println("RECORRER");
		while (iteradorClaves.hasNext()) {
			clave=iteradorClaves.next();
			persona=mapPersonasDniString.get(clave);
			System.out.println(persona);
		}
		System.out.println("-----------");
		//
		Collection<Persona> coleccionPersonas = mapPersonasDniString.values();
		Iterator<Persona> iteradorPersonas = coleccionPersonas.iterator();
		persona = null;
		System.out.println("RECORRER");
		while (iteradorPersonas.hasNext()) {
			persona=iteradorPersonas.next();
			System.out.println(persona);
		}
		System.out.println("-----------");
	}

	public static void main(String[] args) {
		Map<Integer, Persona> mapPersonas = new HashMap<Integer, Persona>();
		Persona persona1 = new Persona(1, "Juan", "Lopez", new Dni("2233445566", 'A'));
		mapPersonas.put(persona1.getCodPersona(), persona1);
		Persona persona2 = new Persona(2, "Marta", "Bilbao", new Dni("2233445577", 'B'));
		mapPersonas.put(persona2.getCodPersona(), persona2);
		Persona persona3 = new Persona(3, "Oscar", "Igartua", new Dni("2233445588", 'C'));
		mapPersonas.put(persona3.getCodPersona(), persona3);
		Persona persona4 = new Persona(4, "Aritz", "Arretxe", new Dni("2233445599", 'D'));
		mapPersonas.put(persona4.getCodPersona(), persona4);

		Map<String, Persona> mapPersonasDniString = new HashMap<String, Persona>();
		mapPersonasDniString.put("2233445566-A", persona1);
		mapPersonasDniString.put(persona2.getDni().toString(), persona2);
		mapPersonasDniString.put(persona3.getDni().toString(), persona3);
		mapPersonasDniString.put(persona4.getDni().toString(), persona4);

		recorrer(mapPersonasDniString);

		Persona personaBuscar = mapPersonasDniString.get("2233445566-A");

		System.out.println(personaBuscar);

		Integer codPersonaBuscar = 3;

		Persona personaEncontrada = mapPersonas.get(codPersonaBuscar);

		System.out.println(personaEncontrada);

		Map<ClavePrimaria, Persona> mapPersonas2 = new HashMap<ClavePrimaria, Persona>();
		mapPersonas2.put(new ClavePrimaria("1", "2"), persona1);
		mapPersonas2.put(new ClavePrimaria("3", "4"), persona2);
		mapPersonas2.put(new ClavePrimaria("5", "6"), persona3);
		mapPersonas2.put(new ClavePrimaria("7", "8"), persona4);

		ClavePrimaria clavePrimariaPersonaBuscar = new ClavePrimaria("1", "2");

		Persona personaEncontrada2 = mapPersonas2.get(clavePrimariaPersonaBuscar);

		System.out.println(personaEncontrada2);

	}
}
