package colecciones;

import geometria.Punto;

public class TestContenedorClasico {
	public static void main(String[] args) {
		Punto punto1 = new Punto(2, 7);
		ContenedorClasico contenedorClasico = new ContenedorClasico(punto1);
		contenedorClasico.setContenido1(new Object());
		contenedorClasico.setContenido1(punto1);
		punto1 = (Punto) contenedorClasico.getContenido1();
		//
		Punto punto2 = new Punto(2, 7);
		Punto punto3 = new Punto(2, 7);
		Punto punto4 = new Punto(2, 7);
		//
		ContenedorClasicoVariosObjetos contenedorClasicoVariosObjetos = new ContenedorClasicoVariosObjetos(punto1,
				punto2, punto3, punto4);
	}

	public static void leerContenidoContenedor(ContenedorClasico contenedorClasico) {
		Punto punto = (Punto) contenedorClasico.getContenido1();
	}

}
