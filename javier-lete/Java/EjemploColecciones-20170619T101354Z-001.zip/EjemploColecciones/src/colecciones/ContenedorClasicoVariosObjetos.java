package colecciones;

public class ContenedorClasicoVariosObjetos {
	Object[] arrayObjetosContenido;

	public ContenedorClasicoVariosObjetos(Object... arrayObjetosContenido) {
		super();
		this.arrayObjetosContenido = arrayObjetosContenido;
	}

}
