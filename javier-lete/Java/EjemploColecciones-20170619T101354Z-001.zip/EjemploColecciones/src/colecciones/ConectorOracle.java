package colecciones;

public class ConectorOracle implements ConectorBD {

	@Override
	public void conectar() {
		System.out.println("conectar Oracle");

	}

	@Override
	public void desconectar() {
		System.out.println("desconectar Oracle");

	}

	@Override
	public void hacerSqlDDL() {
		System.out.println("hacerSqlDDL Oracle");

	}

	@Override
	public void hacerSqlDML() {
		System.out.println("hacerSqlDML Oracle");

	}

}
