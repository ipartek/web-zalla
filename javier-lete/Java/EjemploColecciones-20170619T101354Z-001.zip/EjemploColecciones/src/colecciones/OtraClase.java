package colecciones;

import java.util.ArrayList;
import java.util.List;

public class OtraClase {

	public static List obtenerListOptimizado() {
		return new ArrayOptimizadoList();
	}

}
