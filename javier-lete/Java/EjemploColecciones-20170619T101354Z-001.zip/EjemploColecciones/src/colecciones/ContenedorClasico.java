package colecciones;

public class ContenedorClasico {
	Object contenido1;

	public ContenedorClasico(Object contenido1) {
		super();
		this.contenido1 = contenido1;
	}

	public Object getContenido1() {
		return contenido1;
	}

	public void setContenido1(Object contenido1) {
		this.contenido1 = contenido1;
	}
	
	

}
