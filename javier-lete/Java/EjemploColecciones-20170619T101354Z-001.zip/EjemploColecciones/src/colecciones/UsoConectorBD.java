package colecciones;

public class UsoConectorBD {

	public static void main(String[] args) {
		ConectorBD conectorBD = ObtenerConectorBD.obtenerConexionBD();
		conectorBD.conectar();
		conectorBD.desconectar();
		conectorBD.hacerSqlDDL();
		conectorBD.hacerSqlDML();

	}

}
