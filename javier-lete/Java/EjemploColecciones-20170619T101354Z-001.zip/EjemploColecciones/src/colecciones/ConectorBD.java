package colecciones;

public interface ConectorBD {
	void conectar();
	void desconectar();
	void hacerSqlDDL();
	void hacerSqlDML();

}
