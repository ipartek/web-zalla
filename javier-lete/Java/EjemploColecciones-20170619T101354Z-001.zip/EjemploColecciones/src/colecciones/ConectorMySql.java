package colecciones;

public class ConectorMySql implements ConectorBD {

	@Override
	public void conectar() {
		System.out.println("conectar MySql");

	}

	@Override
	public void desconectar() {
		System.out.println("desconectar MySql");

	}

	@Override
	public void hacerSqlDDL() {
		System.out.println("hacerSqlDDL MySql");

	}

	@Override
	public void hacerSqlDML() {
		System.out.println("hacerSqlDML MySql");

	}

}
