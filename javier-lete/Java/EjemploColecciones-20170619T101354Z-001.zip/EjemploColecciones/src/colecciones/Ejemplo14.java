package colecciones;

import java.util.Vector;

import conduccion.Dni;
import conduccion.Persona;
import geometria.Punto;

public class Ejemplo14 {

	public static void main(String[] args) {
		Vector vectorPuntos = new Vector();
		Punto punto1 = new Punto(1, 2);
		vectorPuntos.add(punto1);
		Punto punto2 = new Punto(3, 4);
		vectorPuntos.add(punto2);
		Punto punto3 = new Punto(5, 6);
		vectorPuntos.add(punto3);
		Dni dni = new Dni("27383444", 'R');
		Persona persona = new Persona("Roberto", "Martin", dni);
		// persona.obtenerInfo();
		// vectorPuntos.add(persona);
		Punto punto = null;
		for (int i = 0; i < vectorPuntos.size(); i++) {
			punto = (Punto) vectorPuntos.get(i);
			System.out.println(punto);
		}
		Vector vectorEnteros = new Vector();
		vectorEnteros.add(new Integer(1));
		vectorEnteros.add(new Integer(2));
		vectorEnteros.add(new Integer(3));
		Integer entero = null;
		for (int i = 0; i < vectorEnteros.size(); i++) {
			entero = (Integer) vectorEnteros.get(i);
			System.out.println(entero);
		}

	}

}
