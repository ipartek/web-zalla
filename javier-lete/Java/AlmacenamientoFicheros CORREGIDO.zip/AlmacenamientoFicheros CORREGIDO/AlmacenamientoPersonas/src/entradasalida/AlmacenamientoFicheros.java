package entradasalida;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import beans.Dni;
import beans.Persona;

public class AlmacenamientoFicheros {
	private static String SEPARADOR_CAMPOS_LINEA_FICHERO = "$";

	public static void guardarPersonas(String nombreFichero, List<Persona> listaPersonas) {
		FileWriter fichero = null;
		PrintWriter pw = null;
		try {
			fichero = new FileWriter(nombreFichero);
			pw = new PrintWriter(fichero);
			System.out.println("Escribiendo en el archivo.txt");
			for (int i = 0; i < listaPersonas.size(); i++) {
				pw.println(personaToLineaFichero(listaPersonas.get(i)));
				// pw.println("----------");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				// Nuevamente aprovechamos el finally para
				// asegurarnos que se cierra el fichero.
				if (null != fichero)
					fichero.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	public static List<Persona> obtenerPersonas(String nombreFichero) {
		List<Persona> listaPersonas = new ArrayList<Persona>();
		try {
			FileReader fr = new FileReader(nombreFichero);
			BufferedReader br = new BufferedReader(fr);
			System.out.println("Leyendo en el archivo.txt");
			String lineaFichero;
			Persona persona = null;
			while ((lineaFichero = br.readLine()) != null) {
				persona = lineaFicheroToPersona(lineaFichero);
				listaPersonas.add(persona);
			}
		} catch (Exception e) {
			System.out.println("ERROR!!!!!111UNOUNO");
		}
		return listaPersonas;
	}

	private static String personaToLineaFichero(Persona persona) {
		return persona.getNombre() + SEPARADOR_CAMPOS_LINEA_FICHERO + persona.getApellido()
				+ SEPARADOR_CAMPOS_LINEA_FICHERO + persona.getDni().getNumero() + SEPARADOR_CAMPOS_LINEA_FICHERO
				+ persona.getDni().getLetra();
	}

	private static Persona lineaFicheroToPersona(String lineaFichero) {
		String[] camposPersona = lineaFichero.split("\\" + SEPARADOR_CAMPOS_LINEA_FICHERO);
		return new Persona(camposPersona[0], camposPersona[1], new Dni(camposPersona[2], camposPersona[3].charAt(0)));
	}

}
