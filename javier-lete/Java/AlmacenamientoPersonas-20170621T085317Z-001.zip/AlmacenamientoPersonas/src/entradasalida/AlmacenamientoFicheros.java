package entradasalida;

import java.util.List;

import beans.Persona;

public class AlmacenamientoFicheros {

	public static void guardarPersonas(String nombreFichero, List<Persona> listaPersonas) {
	}

	public static List<Persona> obtenerPersonas(String nombreFichero) {
		return null;
	}

}
