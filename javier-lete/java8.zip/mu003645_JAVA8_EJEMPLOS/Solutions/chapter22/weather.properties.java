#Properties settings
location=Wasilla, Alaska
highTemperature=72
lowTemperature=41
conditions=mostly cloudy
