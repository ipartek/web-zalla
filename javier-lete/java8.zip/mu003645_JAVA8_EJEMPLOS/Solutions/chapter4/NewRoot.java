package com.java24hours;

class NewRoot {
    public static void main(String[] arguments) {
        int number = 625;
        System.out.println("The square root of "
            + number
            + " is "
            + Math.sqrt(number)
        );
    }
}