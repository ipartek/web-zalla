package com.java24hours;

class Saluton {
    public static void main(String[] arguments) {
        String greeting = "Saluton mondo!";
        System.out.println(greeting);
    }
}
