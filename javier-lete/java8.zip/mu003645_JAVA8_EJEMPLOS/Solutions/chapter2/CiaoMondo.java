package com.java24hours;

class CiaoMondo {
    public static void main(String[] arguments) {
        String greeting = "Ciao mondo!";
        System.out.println(greeting);
    }
}