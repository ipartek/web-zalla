package com.java24hours;

class Square {
   public static void main(String[] arguments) {
      int x = 4;
      int y = 5;
      int sum = (x*x) + (y*y);
      System.out.println("The result of " + x + " squared plus "
          + y + " squared equals " + sum);
   }
}