package com.java24hours;

public class WideReceiver extends BallCarrier {
}

