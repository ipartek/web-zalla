package com.java24hours;

public class FootballPlayer {
    public int number;    
}
