package com.java24hours;

public class TightEnd extends Blocker {
}

