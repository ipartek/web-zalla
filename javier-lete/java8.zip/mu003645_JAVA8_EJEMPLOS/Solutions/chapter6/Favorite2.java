package com.java24hours;

class Favorite2 {
     public static void main(String[] arguments) {
         // set up film information
         String favorite = "chainsaw";
         String guess = "chainsaw";
         System.out.println("Is Fin's favorite weapon a "
             + guess + "?");
         System.out.println("Answer: " + favorite.equals(guess));
    }
}