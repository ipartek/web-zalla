package com.java24hours;

class Favorite {
     public static void main(String[] arguments) {
         // set up film information
         String favorite = "chainsaw";
         String guess = "pool cue";
         System.out.println("Is Fin's favorite weapon a "
             + guess + "?");
         System.out.println("Answer: " + favorite.equals(guess));
    }
}