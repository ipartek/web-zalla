// A program from Appendix A of Sams Teach Yourself Java in 24 Hours
// by Rogers Cadenhead, http://www.java24hours.com/

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
 
/**
  *
  * @author User
  */
public class Spartacus {

    /**
      * @param args the command line arguments
      */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("I am Spartacus!");

    }

 }
