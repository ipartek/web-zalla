// A program from Chapter 5 of Sams Teach Yourself Java in 24 Hours
// by Rogers Cadenhead, http://www.java24hours.com/

package com.java24hours;

class Variable {
   public static void main(String[] arguments) {
      int tops;
      float gradePointAverage;
      char key = 'C';
      String productName = "Larvets";
   }
}