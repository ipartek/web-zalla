// A program from Chapter 2 of Sams Teach Yourself Java in 24 Hours
// by Rogers Cadenhead, http://www.java24hours.com/

package com.java24hours;

class Saluton {
    public static void main(String[] arguments) {
        String greeting = "Saluton mondo!";
        System.out.println(greeting);
    }
}
